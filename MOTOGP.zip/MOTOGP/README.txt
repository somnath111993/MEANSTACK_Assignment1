Assignment 1 - Solution 

----Extract the RAR to Desktop----
----Open "index.html" using your default browser----

The site includes:
1. Page heading and nav bar 
2. 3 Column section(---CLICK on Guidelines tab on Home page---).
3. A 1 column hero unit. 
4. A footer. With social links and site links.  
5. Uses the 960 framework for the "grid". 
6. A section which contains 2 vertical columns. divide the column on the right into 3 rows.
7. Make use of a google font for displaying text 
8. Fixed header with page scroll beneath the header 